Jonathan Lopez
2436878
jonlopez@chapman.edu
CPSC-231-03
MP2 PSL

    For this project, I created two clases for an individual latee and a latee order, along with a driver class for all implementation. I had issues 
     with the overall functionality of my code due to paramater errors. My calcTotal method along with the latteOrders methods were not properly assigning 
     the correct variables. I had various syntax errors when calling my methods in the other classes, but mostly dealt with inconsistent parameter names/typos
      on the Latte constructors. This proved
     to be more difficult due to working with various parts/classes for a program. I also had issues with calcTotal overwritting order summary 
     attributes. I originally used if statments to keep track of order total, but the control flow was very messy and resulted in some addons being 
     updated to the total and others missing completely. I could not figure out the issue so I had to adjust my method with a switch case to 
     better evalaute cost based on each condition/attribute. 
References:
https://learn.zybooks.com/zybook/CHAPMANCPSC231Fall2023/chapter/7/section/4
https://dreel.notion.site/Classes-II-9f24bdd536654201ba70aeed219b1a1b
https://drive.google.com/file/d/1aeYmbe2h-mlG8quG3V0R6ONwfdXq9tY3/view
https://stackoverflow.com/questions/63426789/java-application-grocery-ordering-logic-with-oop